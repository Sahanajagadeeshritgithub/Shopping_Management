package com.shopping_management.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Mall {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long mall_id; // PK
    private String mall_name;
    private String mall_location;
    private String mall_timings;

    // Constructors, Getters, and Setters
    public Mall() {}

    public Mall(Long mall_id, String mall_name, String mall_location, String mall_timings) {
        this.mall_id = mall_id;
        this.mall_name = mall_name;
        this.mall_location = mall_location;
        this.mall_timings = mall_timings;
    }

    public Long getMall_id() {
        return mall_id;
    }

    public void setMall_id(Long mall_id) {
        this.mall_id = mall_id;
    }

    public String getMall_name() {
        return mall_name;
    }

    public void setMall_name(String mall_name) {
        this.mall_name = mall_name;
    }

    public String getMall_location() {
        return mall_location;
    }

    public void setMall_location(String mall_location) {
        this.mall_location = mall_location;
    }

    public String getMall_timings() {
        return mall_timings;
    }

    public void setMall_timings(String mall_timings) {
        this.mall_timings = mall_timings;
    }

	@Override
	public String toString() {
		return "Mall [mall_id=" + mall_id + ", mall_name=" + mall_name + ", mall_location=" + mall_location
				+ ", mall_timings=" + mall_timings + ", getMall_id()=" + getMall_id() + ", getMall_name()="
				+ getMall_name() + ", getMall_location()=" + getMall_location() + ", getMall_timings()="
				+ getMall_timings() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

    
}
