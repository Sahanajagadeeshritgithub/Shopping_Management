package com.shopping_management.demo.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long order_id;

    @Column(nullable = false)
    private LocalDate order_date;

    @ManyToOne
    @JoinColumn(name = "cart_id", nullable = false) // Foreign key referencing Cart table
    private Cart cart;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false) // Foreign key referencing User table
    private User user;

    @Column(nullable = false)
    private double total_amt;

    public Order() {}

    public Order(Long order_id, LocalDate order_date, Cart cart, User user, double total_amt) {
        this.order_id = order_id;
        this.order_date = order_date;
        this.cart = cart;
        this.user = user;
        this.total_amt = total_amt;
    }

    public Long getOrder_id() {
        return order_id;
    }

    public void setOrder_id(Long order_id) {
        this.order_id = order_id;
    }

    public LocalDate getOrder_date() {
        return order_date;
    }

    public void setOrder_date(LocalDate order_date) {
        this.order_date = order_date;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public double getTotal_amt() {
        return total_amt;
    }

    public void setTotal_amt(double total_amt) {
        this.total_amt = total_amt;
    }

    @Override
    public String toString() {
        return "Order [order_id=" + order_id + ", order_date=" + order_date + ", cart=" + cart +
               ", user=" + user + ", total_amt=" + total_amt + "]";
    }
}
