package com.shopping_management.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingManagement1Application {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingManagement1Application.class, args);
	}

}
