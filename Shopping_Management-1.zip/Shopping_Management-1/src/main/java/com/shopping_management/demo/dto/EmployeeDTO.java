package com.shopping_management.demo.dto;

import java.util.Map;

public class EmployeeDTO {
	
	private Long emp_id;
    private String empName;
    private double salary;
    private Map<String, Object> Mall;
    private Map<String, Object> ShopOwner;
    
    
	public Long getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(Long emp_id) {
		this.emp_id = emp_id;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Map<String, Object> getMall() {
		return Mall;
	}
	public void setMall(Map<String, Object> mall) {
		Mall = mall;
	}
	public Map<String, Object> getShopOwner() {
		return ShopOwner;
	}
	public void setShopOwner(Map<String, Object> shopOwner) {
		ShopOwner = shopOwner;
	}
	public EmployeeDTO(Long emp_id, String empName, double salary, Map<String, Object> mall,
			Map<String, Object> shopOwner) {
		super();
		this.emp_id = emp_id;
		this.empName = empName;
		this.salary = salary;
		Mall = mall;
		ShopOwner = shopOwner;
	}
    
    



}
