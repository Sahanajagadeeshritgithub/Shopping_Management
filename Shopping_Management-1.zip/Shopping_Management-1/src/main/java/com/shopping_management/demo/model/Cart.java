package com.shopping_management.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cartId;

    @Column(nullable = false)
    private int totalItems;

    @Column(nullable = false)
    private double totalPrice;


    
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false) 
    private User user;

    public Cart() {
    }

    public Cart(Long cartId, int totalItems, double totalPrice, User user) {
        this.cartId = cartId;
        this.totalItems = totalItems;
        this.totalPrice = totalPrice;
        this.user = user;
    }

    public Long getCartId() {
        return cartId;
    }

    public void setCartId(Long cartId) {
        this.cartId = cartId;
    }

    public int getTotalItems() {
        return totalItems;
    }

    public void setTotalItems(int totalItems) {
        this.totalItems = totalItems;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
    
    

    @Override
    public String toString() {
        return "Cart [cartId=" + cartId + ", totalItems=" + totalItems + ", totalPrice=" + totalPrice + ", user=" + user + "]";
    }
}
