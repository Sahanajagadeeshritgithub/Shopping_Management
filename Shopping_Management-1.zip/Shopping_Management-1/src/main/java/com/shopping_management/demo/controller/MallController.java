package com.shopping_management.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shopping_management.demo.model.Mall;
import com.shopping_management.demo.service.MallService;

@RestController
@RequestMapping("/malls")
public class MallController {

    @Autowired
    private MallService service;

    // Retrieve all
    @GetMapping
    public List<Mall> list() {
        return service.listAll();
    }

    // Retrieve by ID
    @GetMapping("/{id}")
    public ResponseEntity<Mall> get(@PathVariable Long id) {
        try {
            Mall mall = service.get(id);
            return new ResponseEntity<>(mall, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Create operation
    @PostMapping
    public void add(@RequestBody Mall mall) {
        service.save(mall);
    }

    // Update operation
    @PutMapping("/{id}")
    public ResponseEntity<?> update(@RequestBody Mall mall, @PathVariable Long id) {
        try {
            service.get(id); // Check if exists
            service.save(mall);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Delete operation
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
