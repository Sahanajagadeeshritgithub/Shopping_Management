package com.shopping_management.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shopping_management.demo.model.User;
import com.shopping_management.demo.repository.UserRepository;

@Service
@Transactional
public class UserService {

    @Autowired
    private UserRepository repository;

    public List<User> listAll() {
        return repository.findAll();
    }

    public User get(Long id) {
        return repository.findById(id).orElse(null);
    }

    public void save(User user) {
        repository.save(user);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
