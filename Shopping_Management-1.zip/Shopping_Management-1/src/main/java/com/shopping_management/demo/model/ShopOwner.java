package com.shopping_management.demo.model;

import jakarta.persistence.*;

@Entity
public class ShopOwner {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int shopId;

    @Column(nullable = false)
    private String shopOwner;

    @Column(nullable = false)
    private String shopName;

    @ManyToOne
    @JoinColumn(name = "mall_id", nullable = false) // Foreign key referencing Mall table
    private Mall mall; // Changed to Mall type

    public ShopOwner() {}

    public ShopOwner(int shopId, String shopOwner, String shopName, Mall mall) {
        this.shopId = shopId;
        this.shopOwner = shopOwner;
        this.shopName = shopName;
        this.mall = mall;
    }

    public int getShopId() {
        return shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
    }

    public String getShopOwner() {
        return shopOwner;
    }

    public void setShopOwner(String shopOwner) {
        this.shopOwner = shopOwner;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public Mall getMall() {
        return mall;
    }

    public void setMall(Mall mall) {
        this.mall = mall;
    }

	@Override
	public String toString() {
		return "ShopOwner [shopId=" + shopId + ", shopOwner=" + shopOwner + ", shopName=" + shopName + ", mall=" + mall
				+ "]";
	}


}
