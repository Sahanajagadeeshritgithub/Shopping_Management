package com.shopping_management.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shopping_management.demo.model.Cart;
import com.shopping_management.demo.repository.CartRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class CartService {

    @Autowired
    private CartRepository repository;

    public List<Cart> listAll() {
        return repository.findAll();
    }

    public Cart get(Long id) {
        return repository.findById(id).orElse(null);
    }

    public void save(Cart cart) {
        repository.save(cart);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
    

    
}
