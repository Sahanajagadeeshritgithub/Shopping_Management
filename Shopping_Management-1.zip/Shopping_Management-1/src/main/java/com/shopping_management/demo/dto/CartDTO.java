package com.shopping_management.demo.dto;

import java.util.Map;

public class CartDTO {
    private Long cartId;
    private int totalItems;
    private double totalPrice;
    private Map<String, Object> user;

    public CartDTO(Long cartId, int totalItems, double totalPrice, Map<String, Object> user) {
        this.cartId = cartId;
        this.totalItems = totalItems;
        this.totalPrice = totalPrice;
        this.user = user;
    }

    // Getters and Setters
    public Long getCartId() {
        return cartId;
    }

    public void setCartId(Long cartId) {
        this.cartId = cartId;
    }

    public int getTotalItems() {
        return totalItems;
    }

    public void setTotalItems(int totalItems) {
        this.totalItems = totalItems;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Map<String, Object> getUser() {
        return user;
    }

    public void setUser(Map<String, Object> user) {
        this.user = user;
    }
}
