package com.shopping_management.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.shopping_management.demo.dto.ShopOwnerDTO;
import com.shopping_management.demo.model.ShopOwner;
import com.shopping_management.demo.service.ShopOwnerService;

@RestController
@RequestMapping("/shopowners")
public class ShopOwnerController {

    @Autowired
    private ShopOwnerService service;

    // Retrieve all including mall data members
    @GetMapping
    public List<ShopOwnerDTO> list() {
        List<ShopOwner> shopowners = service.listAll();

        return shopowners.stream().map(shopowner -> {
            Map<String, Object> mallResponse = new HashMap<>();
            
                mallResponse.put("mall_id", shopowner.getMall().getMall_id());
                mallResponse.put("mall_name", shopowner.getMall().getMall_name());
            
            return new ShopOwnerDTO(shopowner.getShopId(), shopowner.getShopOwner(), shopowner.getShopName(), mallResponse);
        }).collect(Collectors.toList());
    }

    // Retrieve by ID
    @GetMapping("/{id}")
    public ResponseEntity<ShopOwnerDTO> get(@PathVariable Long id) {
        try {
            ShopOwner shopowner = service.get(id);
            Map<String, Object> mallResponse = new HashMap<>();
            
            mallResponse.put("mall_id", shopowner.getMall().getMall_id());
            mallResponse.put("mall_name", shopowner.getMall().getMall_name());
            
            ShopOwnerDTO shopownerDTO= new ShopOwnerDTO(shopowner.getShopId(), shopowner.getShopOwner(), shopowner.getShopName(), mallResponse);

            return new ResponseEntity<>(shopownerDTO, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Create operation
    @PostMapping
    public void add(@RequestBody ShopOwner shopOwner) {
        service.save(shopOwner);
    }

    // Update operation
    @PutMapping("/{id}")
    public ResponseEntity<String> update(@RequestBody ShopOwner shopOwner, @PathVariable Long id) {
        try {
            service.get(id); // Check if exists
            service.save(shopOwner);
            return new ResponseEntity<>("ShopOwner updated successfully!", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("ShopOwner not found", HttpStatus.NOT_FOUND);
        }
    }

    // Delete operation
    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        try {
            service.delete(id);
            return new ResponseEntity<>("ShopOwner deleted successfully!", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to delete ShopOwner", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
