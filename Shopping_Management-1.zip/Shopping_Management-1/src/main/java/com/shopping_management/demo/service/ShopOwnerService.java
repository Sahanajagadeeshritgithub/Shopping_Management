package com.shopping_management.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shopping_management.demo.model.ShopOwner;
import com.shopping_management.demo.repository.ShopOwnerRepository;

@Service
@Transactional
public class ShopOwnerService {

    @Autowired
    private ShopOwnerRepository repository;

    public List<ShopOwner> listAll() {
        return repository.findAll();
    }

    public ShopOwner get(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("ShopOwner not found"));
    }

    public void save(ShopOwner shopOwner) {
        repository.save(shopOwner);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
