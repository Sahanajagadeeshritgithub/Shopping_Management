package com.shopping_management.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "employee")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long empId;

    @Column(nullable = false)
    private String empName;

    @Column(nullable = false)
    private double salary;

    @ManyToOne
    @JoinColumn(name = "mall_id", nullable = false) // Foreign key referencing Mall table
    private Mall mall;

    @ManyToOne
    @JoinColumn(name = "shop_id", nullable = false) // Foreign key referencing ShopOwner table
    private ShopOwner shopOwner;

    public Long getEmpId() {
        return empId;
    }

    public void setEmpId(Long empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public Mall getMall() {
        return mall;
    }

    public void setMall(Mall mall) {
        this.mall = mall;
    }

    public ShopOwner getShopOwner() {
        return shopOwner;
    }

    public void setShopOwner(ShopOwner shopOwner) {
        this.shopOwner = shopOwner;
    }

    @Override
    public String toString() {
        return "Employee [empId=" + empId + ", empName=" + empName + ", salary=" + salary +
               ", mall=" + mall + ", shopOwner=" + shopOwner + "]";
    }

    public Employee(Long empId, String empName, double salary, Mall mall, ShopOwner shopOwner) {
        this.empId = empId;
        this.empName = empName;
        this.salary = salary;
        this.mall = mall;
        this.shopOwner = shopOwner;
    }

    public Employee() {}
}
