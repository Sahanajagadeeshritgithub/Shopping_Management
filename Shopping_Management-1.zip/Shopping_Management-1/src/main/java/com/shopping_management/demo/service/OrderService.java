package com.shopping_management.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shopping_management.demo.model.Order;
import com.shopping_management.demo.repository.OrderRepository;

@Service
@Transactional
public class OrderService {

    @Autowired
    private OrderRepository repository;

    public List<Order> listAll() {
        return repository.findAll();
    }

    public Order get(Long id) {
        return repository.findById(id).orElse(null);
    }

    public void save(Order order) {
        repository.save(order);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
