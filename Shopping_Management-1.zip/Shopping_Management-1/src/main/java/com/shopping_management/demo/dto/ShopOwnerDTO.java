package com.shopping_management.demo.dto;

import java.util.Map;

import jakarta.persistence.Column;

public class ShopOwnerDTO {

	private int shop_id;
	private String shop_owner;
	private String shop_name;
	@Column(nullable = false)
	private  Map<String,Object>mall;
	
	public int getShop_id() {
		return shop_id;
	}
	public void setShop_id(int shop_id) {
		this.shop_id = shop_id;
	}
	public String getShop_owner() {
		return shop_owner;
	}
	public void setShop_owner(String shop_owner) {
		this.shop_owner = shop_owner;
	}
	public String getShop_name() {
		return shop_name;
	}
	public void setShop_name(String shop_name) {
		this.shop_name = shop_name;
	}
	public Map<String, Object> getMall() {
		return mall;
	}
	public void setMall(Map<String, Object> mall) {
		this.mall = mall;
	}
	public ShopOwnerDTO(int shop_id, String shop_owner, String shop_name, Map<String, Object> mall) {
		super();
		this.shop_id = shop_id;
		this.shop_owner = shop_owner;
		this.shop_name = shop_name;
		this.mall = mall;
	}
	
	

}
