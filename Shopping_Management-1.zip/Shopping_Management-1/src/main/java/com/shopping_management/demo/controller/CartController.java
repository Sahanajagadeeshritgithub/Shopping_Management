package com.shopping_management.demo.controller;

import java.util.HashMap
;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shopping_management.demo.dto.CartDTO;
import com.shopping_management.demo.model.Cart;
import com.shopping_management.demo.service.CartService;

@RestController
@RequestMapping("/carts")
public class CartController {

    @Autowired
    private CartService service;

    // Retrieve all
   /* @GetMapping
    public List<Cart> list() {
        return service.listAll();
    }*/
    
    // Retrieve all carts with selected user details (using existing User entity)
    @GetMapping
    public List<CartDTO> list() {
        List<Cart> carts = service.listAll();

        return carts.stream().map(cart -> {Map<String, Object> userResponse = new HashMap<>();// Create a user map with required fields
            userResponse.put("user_id", cart.getUser().getUser_id());
            userResponse.put("user_name", cart.getUser().getUser_name());
         // Map Cart to CartDTO
            return new CartDTO(cart.getCartId(), cart.getTotalItems(), cart.getTotalPrice(), userResponse);
        }).collect(Collectors.toList());
    }

    // Retrieve by ID
    @GetMapping("/{id}")
    public ResponseEntity<CartDTO> get(@PathVariable Long id) {
        try {
            Cart cart = service.get(id);
            // Create a user map with required fields
            Map<String, Object> userResponse = new HashMap<>();
            userResponse.put("user_id", cart.getUser().getUser_id());
            userResponse.put("user_name", cart.getUser().getUser_name());
         // Map Cart to CartDTO
            CartDTO cartDTO = new CartDTO(cart.getCartId(), cart.getTotalItems(), cart.getTotalPrice(), userResponse);
            
            return new ResponseEntity<>(cartDTO, HttpStatus.OK); 

        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    //Create operation
    @PostMapping
    public void add(@RequestBody Cart cart) {
        service.save(cart);
    }

    // Update operation
    @PutMapping("/{id}")
    public ResponseEntity<?> update(@RequestBody Cart cart, @PathVariable Long id) {
        try {
            service.get(id); // Check if exists
            service.save(cart);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Delete operation
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
    
    
    

   }


    	
 
 





















